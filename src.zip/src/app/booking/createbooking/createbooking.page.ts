import { Component, OnInit } from '@angular/core';
import { Place } from 'src/app/tab1/place.model';
import { ActivatedRoute } from '@angular/router';
import { PlaceService } from 'src/app/tab1/place.service';

@Component({
  selector: 'app-createbooking',
  templateUrl: './createbooking.page.html',
  styleUrls: ['./createbooking.page.scss'],
})
export class CreatebookingPage implements OnInit {
  place: Place;
  id: String;
  constructor(private route: ActivatedRoute, private placeService: PlaceService) { }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('placeId');
    console.log(this.id);
    this.place = this.placeService.getPlace(this.id);
    console.log(this.place);
  }

}
